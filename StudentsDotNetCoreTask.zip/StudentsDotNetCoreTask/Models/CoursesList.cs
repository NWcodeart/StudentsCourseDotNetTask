﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentsDotNetCoreTask.Models
{
    public class CoursesList
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; }
    }
}
